# PlatformerEngine By Seth Peace
## About
This is a Game Engine created for my Python III class.

## Status
This project is currently in the Release Phase!!!

## Credits
   * Code By Seth Peace
   * Art By [Kenney.nl](https://kenney.nl)
   * Background By [wallpaper safari](https://wallpapersafari.com/w/rpsTXa)
   * Coin Sound By [plasterbrain on freesound](https://freesound.org/people/plasterbrain/sounds/242857/)
   * You Win Sound By [FunWithSound on freesound](https://freesound.org/people/FunWithSound/sounds/456966/)
   * Background Music By [Bensound](https://www.bensound.com/royalty-free-music/track/extreme-action)