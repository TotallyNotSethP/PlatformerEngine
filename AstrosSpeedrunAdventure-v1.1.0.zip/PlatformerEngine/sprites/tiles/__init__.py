from PlatformerEngine.sprites.tiles.grass import Grass
from PlatformerEngine.sprites.tiles.sand import Sand
from PlatformerEngine.sprites.tiles.snow import Snow
from PlatformerEngine.sprites.tiles.castle import Castle
from PlatformerEngine.sprites.tiles.dirt import Dirt
from PlatformerEngine.sprites.tiles.empty import Empty
